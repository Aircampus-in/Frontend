var myName =1;
console.log(myName);